"""Current-consumer enumeration and isolated native mesh sweep; not task dynamics."""
import os, json, copy, traceback, tempfile, time
from pathlib import Path
import xml.etree.ElementTree as ET

REPO = Path('/home/summer/spd-zsm')
OUT = Path('/tmp/spd-calibration-runtime-audit-rx1s3u1r/manifests')
tempfile.tempdir = str(OUT)
import mujoco
from dex_scenes.randomization.assets import xml_common, calibrated_props, inhand
ASSETS = xml_common._ASSETS_DIR
cases, targets, enumeration, variants = [], {}, {}, []

def relative(p):
    p = Path(p).resolve()
    return str(p.relative_to(REPO)) if p.is_relative_to(REPO) else str(p)

def marker(kind, cid):
    with (OUT / f'{kind}__{cid}.marker').open('w') as f:
        f.write(cid)

def case(cid, kind, fn, **meta):
    marker('BEGIN', cid)
    record = {'id':cid, 'kind':kind, **meta}
    try:
        result = fn(record)
        record['status'] = 'success'
    except Exception as exc:
        record.update(status='failed', error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
        result = None
    finally:
        marker('END', cid)
        cases.append(record)
    return result

def add_mesh(attrs, origin):
    path = Path(attrs['file']).resolve()
    if path.suffix.lower() != '.obj' or not (path.is_relative_to(ASSETS / 'calibrated_collision') or path.is_relative_to(ASSETS / 'calibrated_props')):
        return
    params = {k:v for k,v in attrs.items() if k not in {'name','file'}}
    # Preserve every supplied mesh parameter; names are local to the isolated wrapper.
    key = json.dumps([str(path),params], sort_keys=True)
    if key not in targets:
        targets[key] = {'path':relative(path), 'absolute_path':str(path), 'mesh_parameters':params, 'origins':[]}
    if origin not in targets[key]['origins']:
        targets[key]['origins'].append(origin)


def load_manifests(rec):
    collision = xml_common._calibrated_collision_manifest()
    props = calibrated_props._manifest()
    enumeration.update(collision_mesh_source_count=len(collision['meshes']), collision_model_source_count=len(collision['models']), collision_part_kind_count=len(collision['parts']), props_variant_count=len(props['variants']), props_geometry_count=len(props['geometry']))
    (OUT/'resolved_collision_manifest.json').write_text(json.dumps(collision, indent=2))
    (OUT/'resolved_props_manifest.json').write_text(json.dumps(props, indent=2))
    return collision, props

collision, props = case('manifests', 'real_manifest_readers', load_manifests)

# Every key is passed through the real replacement/marker reader and application.
# This is a synthetic selection input, not a claim that all source keys are used by a task.
for i, source in enumerate(sorted(collision['meshes'])):
    def resolve(rec, source=source):
        root = ET.Element('mujoco')
        asset = ET.SubElement(root,'asset')
        ET.SubElement(asset,'mesh',name='source',file=str(ASSETS/source))
        body = ET.SubElement(ET.SubElement(root,'worldbody'),'body')
        ET.SubElement(body,'geom',type='mesh',mesh='source')
        xml_common._apply_calibrated_meshes(root)
        meshes = root.findall('asset/mesh')
        rec['resolved_meshes'] = [relative(m.get('file')) for m in meshes]
        for m in meshes: add_mesh(m.attrib, 'collision_mesh:'+source)
    case(f'collision_{i:04d}', 'real_apply_on_synthetic_source_declaration', resolve, source=source)

# All current variants are genuinely parsed and apply_calibrated_prop is invoked by the importer.
for i, variant in enumerate(sorted(props['variants'])):
    def parse_prop(rec, variant=variant):
        directory = ASSETS/variant
        parsed = inhand._inhand_parse_model_xml(directory)
        calibrated = []
        for mesh in parsed['meshes']:
            attrs = {'file':str(directory/mesh['file']), **mesh['extra']}
            add_mesh(attrs, 'props_variant:'+variant)
            if Path(attrs['file']).is_relative_to(ASSETS/'calibrated_props'):
                calibrated.append(relative(attrs['file']))
        rec.update(calibrated_meshes=calibrated, importer_mesh_count=len(parsed['meshes']), collision_geom_count=len(parsed['col_geoms']), has_calibrated_inertial='inertial' in parsed)
        variants.append({'variant':variant,'geometry':props['variants'][variant]['geometry'],'calibrated_meshes':calibrated})
    case(f'props_{i:03d}', 'real_inhand_variant_importer', parse_prop, variant=variant)

# The real sorting preprocessor copies original visual mesh scale to every parts target.
def parts(rec):
    template = REPO/'assets/scenes/templates/sorting_nuts_bolts.xml'
    root = ET.parse(template).getroot()
    xml_common._apply_calibrated_meshes(root)
    rec['template'] = relative(template)
    rec['resolved_meshes'] = []
    for mesh in root.findall('asset/mesh'):
        file = mesh.get('file','')
        if Path(file).is_absolute():
            add_mesh(mesh.attrib, 'sorting_template_parts_and_collision')
            rec['resolved_meshes'].append(relative(file))
case('sorting_parts', 'real_template_sorting_preprocessor', parts)

# Enumerate each override via real importer and compile the unmodified imported model.
for i, source in enumerate(sorted(collision['models'])):
    def model_parse(rec, source=source):
        root = xml_common._calibrated_variant_root(ASSETS/source)
        xml_common._apply_calibrated_meshes(root)
        rec['resolved_meshes'] = []
        for mesh in root.findall('asset/mesh'):
            add_mesh(mesh.attrib, 'model_override:'+source)
            rec['resolved_meshes'].append(relative(mesh.get('file')))
    case(f'model_parse_{i:02d}', 'real_replacement_model_importer', model_parse, source=source, replacement=collision['models'][source])
    def model_compile(rec, source=source):
        model = xml_common._calibrated_variant_model(ASSETS/source)
        rec.update(nmesh=model.nmesh,ngeom=model.ngeom,nbody=model.nbody)
    case(f'model_compile_{i:02d}', 'real_replacement_model_native_compile', model_compile, source=source, replacement=collision['models'][source])

ordered = sorted(targets.values(), key=lambda t:(t['path'],json.dumps(t['mesh_parameters'],sort_keys=True)))
for i,t in enumerate(ordered): t['id'] = f'target_{i:05d}'
(OUT/'targets.json').write_text(json.dumps(ordered,indent=2))
(OUT/'variants.json').write_text(json.dumps(variants,indent=2))

def native_compile(batch, rec):
    root = ET.Element('mujoco',model='isolated_calibration_asset_probe')
    ET.SubElement(root,'compiler',angle='radian')
    asset = ET.SubElement(root,'asset')
    world = ET.SubElement(root,'worldbody')
    for i,t in enumerate(batch):
        name = f'probe_mesh_{i}'
        ET.SubElement(asset,'mesh',name=name,file=t['absolute_path'],**t['mesh_parameters'])
        body = ET.SubElement(world,'body',name=f'fixed_body_{i}')
        ET.SubElement(body,'geom',type='mesh',mesh=name)
    xml = ET.tostring(root,encoding='unicode')
    (OUT/(rec['id']+'.xml')).write_text(xml)
    model = mujoco.MjModel.from_xml_string(xml)
    rec.update(nmesh=model.nmesh,ngeom=model.ngeom,compiled_target_ids=[t['id'] for t in batch])

for start in range(0,len(ordered),32):
    batch = ordered[start:start+32]
    cid = f'native_batch_{start//32:04d}'
    case(cid,'synthetic_fixed_body_native_mesh_batch',lambda rec,batch=batch:native_compile(batch,rec),target_ids=[t['id'] for t in batch],target_paths=[t['path'] for t in batch])
    if cases[-1]['status'] == 'failed':
        # Do not hide the failed batch. Isolate its unchanged target declarations to attribute failures.
        for target in batch:
            case(f'native_isolate_{target["id"]}','synthetic_fixed_body_native_failure_isolation',lambda rec,t=target:native_compile([t],rec),target_ids=[target['id']],target_paths=[target['path']],failed_parent_case=cid)

(OUT/'probe_result.json').write_text(json.dumps({'environment':{'python':os.sys.executable,'mujoco':mujoco.__version__,'assets_root':str(ASSETS),'cwd':str(Path.cwd()),'SPD_ASSETS_ROOT':os.environ.get('SPD_ASSETS_ROOT'),'SPD_TASK_MATERIAL_FRICTION_DIR':os.environ.get('SPD_TASK_MATERIAL_FRICTION_DIR'),'SPD_MATERIAL_FRICTION_CONFIG':os.environ.get('SPD_MATERIAL_FRICTION_CONFIG')},'enumeration':enumeration,'cases':cases,'unique_target_paths':len({t['path'] for t in ordered}),'target_declaration_count':len(ordered)},indent=2))
print(json.dumps({'cases':len(cases),'failed_cases':sum(c['status']=='failed' for c in cases),'targets':len(ordered),'unique_paths':len({t['path'] for t in ordered})}),flush=True)
