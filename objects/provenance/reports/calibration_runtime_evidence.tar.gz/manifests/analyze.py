"""Analyze saved native file-open evidence outside the traced process."""
import json, re, hashlib
from pathlib import Path
from collections import defaultdict, Counter
REPO=Path('/home/summer/spd-zsm')
OUT=Path('/tmp/spd-calibration-runtime-audit-rx1s3u1r/manifests')
raw=json.loads((OUT/'probe_result.json').read_text())
targets=json.loads((OUT/'targets.json').read_text())
classification=json.loads((REPO/'assets/objects/provenance/reports/calibration_classification.json').read_text())
classified={x['path']:x for x in classification['files']}
unknown={x['path'] for x in classification['files'] if x['primary_category']=='unknown' and x['path'].endswith('.obj')}
cases={c['id']:c for c in raw['cases']}
observed={}
failed_opens=[]
marker_counts=Counter()
pending={}
active=None
unmatched=[]
trace=OUT/'trace.log'
for lineno, line in enumerate(trace.open(),1):
    line=line.rstrip('\n')
    pid_match=re.match(r'\s*(\d+)\s+(.*)',line)
    if not pid_match: continue
    pid, text=pid_match.groups()
    if '<unfinished ...>' in text:
        pending[pid]=(lineno,text.replace('<unfinished ...>',''))
        continue
    resumed=re.match(r'<\.\.\. (\w+) resumed>(.*)',text)
    if resumed:
        if pid not in pending:
            unmatched.append({'line':lineno,'text':line}); continue
        first, prefix=pending.pop(pid)
        text=prefix+resumed.group(2)
    result=re.search(r'= (\d+)<([^>]+)>\s*$',text)
    if result:
        canonical=result.group(2)
        marker=re.search(r'/(BEGIN|END)__(.+)\.marker$',canonical)
        if marker:
            kind,cid=marker.groups()
            marker_counts[kind]+=1
            if kind=='BEGIN':
                if active is not None: unmatched.append({'line':lineno,'nested_begin':cid,'active':active})
                active=cid
            else:
                if active!=cid: unmatched.append({'line':lineno,'unexpected_end':cid,'active':active})
                active=None
            continue
        if canonical.startswith(str(REPO/'assets')+'/'):
            relative=str(Path(canonical).relative_to(REPO))
            obj=observed.setdefault(relative,{'path':relative,'open_count':0,'case_counts':{},'native_mesh_open_count':0,'example_trace_lines':[]})
            obj['open_count']+=1
            cid=active or 'unattributed'
            obj['case_counts'][cid]=obj['case_counts'].get(cid,0)+1
            if relative.endswith('.obj'):
                # Probe never Python-opens any OBJ: only MuJoCo native compilers can produce these opens.
                obj['native_mesh_open_count']+=1
            if len(obj['example_trace_lines'])<3: obj['example_trace_lines'].append(lineno)
    elif re.search(r'= -1 ',text):
        quoted=re.search(r'"((?:\\.|[^"\\])*)"',text)
        if quoted:
            requested=quoted.group(1)
            if 'calibrated_collision' in requested or 'calibrated_props' in requested:
                p=Path(requested)
                resolved=str(p.resolve().relative_to(REPO)) if p.is_absolute() and p.resolve().is_relative_to(REPO) else requested
                failed_opens.append({'case_id':active,'requested':requested,'resolved_path':resolved,'line':lineno,'syscall':text,'candidate_hit':resolved in unknown})
compiled_ids={tid for c in raw['cases'] if c['status']=='success' for tid in c.get('compiled_target_ids',[])}
compiled_paths={t['path'] for t in targets if t['id'] in compiled_ids}
target_paths={t['path'] for t in targets}
opened_paths={p for p,o in observed.items() if o['native_mesh_open_count']}
opened_target_paths=target_paths & opened_paths
hits=[]
for p in sorted(unknown & set(observed)):
    hits.append(observed[p])
for o in failed_opens:
    if o['candidate_hit']: hits.append(o)
for c in raw['cases']:
    c['observed_asset_paths']=[p for p,o in observed.items() if c['id'] in o['case_counts']]
source_hashes=json.loads((OUT/'source_hashes.json').read_text())
for c in raw['cases']:
    if c['kind']=='real_inhand_variant_importer':
        p='assets/objects/'+c['variant']+'/model.xml'
        source_hashes[p]=hashlib.sha256((REPO/p).read_bytes()).hexdigest()
    if c['kind']=='real_replacement_model_importer':
        p='assets/objects/calibrated_collision/'+c['replacement']
        source_hashes[p]=hashlib.sha256((REPO/p).read_bytes()).hexdigest()
production_proof=[]
for p in sorted(opened_target_paths):
    info=classified.get(p,{})
    if info.get('primary_category')=='production':
        production_proof.append({'path':p,'primary_category':info['primary_category'],'open_count':observed[p]['open_count'],'case_ids':list(observed[p]['case_counts']),'example_trace_lines':observed[p]['example_trace_lines']})
        if len(production_proof)==3: break
result={
 'suite':'manifest-driven candidate/native-loader sweep',
 'method':{
  'enumeration':'Invoke current xml_common._calibrated_collision_manifest (including marker overrides), actual _apply_calibrated_meshes once for every returned source key, calibrated_props._manifest and _inhand_parse_model_xml for every returned variant, actual sorting template preprocessor for parts, and replacement-model importer/native compiler for every models entry.',
  'native_sweep':'Deduplicate canonical calibrated OBJ path + supplied mesh parameters, then compile each declaration using actual mujoco.MjModel.from_xml_string in batches of 32 fixed-body geoms. Failed batches remain failed and their unchanged declarations are isolated individually for attribution.',
  'tracer':'strace -f -yy -s 4096 -e trace=open,openat,openat2,chdir; successful canonical FD annotations; sequential BEGIN/END markers; unfinished/resumed syscalls joined by PID.',
  'no_inventory_hashing_inside_trace':True,
  'native_obj_evidence':'The probe performs no Python OBJ opens. Successful OBJ open syscalls are generated by genuine model importer native compiles or explicitly labeled synthetic native mesh wrappers.'
 },
 'environment':raw['environment'],
 'cases':raw['cases'],
 'observed_asset_opens':sorted(observed.values(),key=lambda x:x['path']),
 'candidate_hits':hits,
 'failed_calibrated_asset_opens':failed_opens,
 'trace_path':str(trace),'trace_sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),
 'probe_source_path':str(OUT/'probe.py'),'probe_source_sha256':hashlib.sha256((OUT/'probe.py').read_bytes()).hexdigest(),
 'analyzer_source_path':str(OUT/'analyze.py'),'analyzer_source_sha256':hashlib.sha256((OUT/'analyze.py').read_bytes()).hexdigest(),
 'source_hashes':source_hashes,
 'current_manifest_snapshots':{'collision':str(OUT/'resolved_collision_manifest.json'),'props':str(OUT/'resolved_props_manifest.json')},
 'targets_path':str(OUT/'targets.json'),'variants_path':str(OUT/'variants.json'),
 'known_production_native_open_proof':production_proof,
 'failures':[c for c in raw['cases'] if c['status']=='failed'],
 'warnings':[{'source':'native probe stderr captured by execution tool','message':'QH7089 qhull precision warning: The initial hull is narrow. Cosine of the minimum angle is 0.9999999999999999. Qhull may produce a wide facet.','effect':'All requested native compiles returned successfully; no suppression, mesh modification, or Qhull option override was applied.','case_attribution':'Not available: stderr was not per-case redirected; raw execution warning retained in probe_execution_output.txt.'}],
 'missing_or_uncompiled_targets':[t for t in targets if t['id'] not in compiled_ids],
 'targets_without_native_open':sorted(target_paths-opened_paths),
 'trace_integrity':{'begin_markers':marker_counts['BEGIN'],'end_markers':marker_counts['END'],'unmatched_records':unmatched,'pending_syscalls':pending,'active_case_at_end':active},
 'limitations':[
  'This is a manifest-driven candidate/native-loader sweep, NOT an all-task dynamics run: no stepping, contacts, bind/reset/controller lifecycle, or task success is tested.',
  'Collision mesh manifest selections are exhaustive but their source declarations are synthetic unit-scale inputs to the real replacement reader. Original mesh parameters are retained wherever supplied by genuine props/model importers or the actual sorting template; extra path+parameter targets are compiled independently.',
  'Eight cabinet and 26 conveyor direct-template assets are outside this manifest-only suite; scene suite owns their runtime template coverage.',
  'No claim is made about future manifest changes, arbitrary dynamic out-of-manifest path construction, external callers, external asset roots, or files selected outside these current readers.',
  'Unknown candidates are compared only during post-trace analysis; none is opened for inventory hashing or force-loaded. Zero observed hits does not establish universal nonuse or authorize deletion.'
 ],
 'summary':{
  **raw['enumeration'],
  'props_variants_invoked':sum(c['kind']=='real_inhand_variant_importer' for c in raw['cases']),
  'props_variants_successfully_imported':sum(c['kind']=='real_inhand_variant_importer' and c['status']=='success' for c in raw['cases']),
  'model_overrides_native_compiled':sum(c['kind']=='real_replacement_model_native_compile' and c['status']=='success' for c in raw['cases']),
  'declared_resolved_target_count':len(targets), 'unique_resolved_calibrated_obj_paths':len(target_paths),
  'compiled_target_count':len(compiled_ids),'unique_compiled_target_paths':len(compiled_paths),
  'actual_opened_calibrated_target_paths':len(opened_target_paths),'actual_opened_all_obj_paths':len(opened_paths),'actual_opened_asset_paths':len(observed),
  'unique_collision_target_paths':sum(p.startswith('assets/objects/calibrated_collision/') for p in target_paths),
  'unique_props_target_paths':sum(p.startswith('assets/objects/calibrated_props/') for p in target_paths),
  'unknown_candidate_inventory_count':len(unknown),'unknown_candidate_hit_count':len(hits),
  'case_count':len(raw['cases']),'failed_case_count':sum(c['status']=='failed' for c in raw['cases']),
  'uncompiled_target_count':len(targets)-len(compiled_ids),'targets_without_native_open_count':len(target_paths-opened_paths)
 }
}
(OUT/'result.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result['summary'],indent=2))
print('Failures:',[(c['id'],c.get('error','')) for c in result['failures']])
print('Native production proof:',production_proof)
print('Trace integrity:',result['trace_integrity'])
