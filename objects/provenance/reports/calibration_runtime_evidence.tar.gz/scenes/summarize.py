"""Offline summary. Never included in strace and never reads candidate OBJ bytes."""
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path('/home/summer/spd-zsm')
WORK = Path('/tmp/spd-calibration-runtime-audit-rx1s3u1r/scenes')
TRACE = WORK / 'trace.log'


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + '\n')


def relative(path):
    path = os.path.normpath(path)
    if path.startswith(str(ROOT) + '/'):
        return path[len(str(ROOT)) + 1:]
    return None


classification_path = ROOT / 'assets/objects/provenance/reports/calibration_classification.json'
classification = json.loads(classification_path.read_text())
candidates = {entry['path'] for entry in classification['files']
              if entry.get('primary_category') == 'unknown' and entry['path'].lower().endswith('.obj')}
production = {entry['path'] for entry in classification['files'] if entry.get('primary_category') == 'production'}
asset_events = []
failed_asset_opens = []
all_repo_paths = set()
write_attempts = []
markers = []
pending = {}
parse_issues = []
current_case = None
current_phase = 'suite_startup'
marker_prefix = str(WORK / 'markers') + '/'
line_count = 0
for line_count, line in enumerate(TRACE.open(), 1):
    match = re.match(r'\s*(\d+)\s+(.*)', line.rstrip())
    if not match:
        continue
    pid, call = match.groups()
    case_id, phase = current_case, current_phase
    if '<unfinished ...>' in call:
        pending[pid] = (call.split('<unfinished ...>')[0], line_count, case_id, phase)
        continue
    resumed = re.match(r'<\.\.\. (\w+) resumed>(.*)', call)
    if resumed:
        previous = pending.pop(pid, None)
        if previous is None:
            parse_issues.append({'line': line_count, 'problem': 'resumed syscall without unfinished record'})
            continue
        prefix, event_line, case_id, phase = previous
        call = prefix + resumed.group(2)
    else:
        event_line = line_count
    if not re.match(r'open(?:at2|at)?\(', call):
        continue
    success = re.search(r'\)\s+=\s+(\d+)<([^>]+)>', call)
    failure = re.search(r'\)\s+=\s+-1\s+(\w+)', call)
    if success:
        target = success.group(2)
        if target.endswith(' (deleted)'):
            target = target[:-10]
    elif failure:
        quoted = re.search(r'"((?:[^"\\]|\\.)*)"', call)
        if not quoted:
            parse_issues.append({'line': event_line, 'problem': 'failed open path unparsed'})
            continue
        name = bytes(quoted.group(1), 'utf8').decode('unicode_escape')
        if os.path.isabs(name):
            target = name
        else:
            directory = re.match(r'openat(?:2)?\(\d+<([^>]+)>', call)
            target = os.path.join(directory.group(1) if directory else str(WORK), name)
    else:
        parse_issues.append({'line': event_line, 'problem': 'open result unparsed', 'call': call})
        continue
    if success and target.startswith(marker_prefix):
        marker = Path(target).name
        markers.append({'marker': marker, 'pid': int(pid), 'trace_line': event_line})
        if marker.startswith('BEGIN__'):
            current_case = marker[len('BEGIN__'):]
            current_phase = 'worker_startup'
        elif marker.startswith('PHASE__'):
            _, marked_case, current_phase = marker.split('__', 2)
            if marked_case != current_case:
                parse_issues.append({'line': event_line, 'problem': 'phase/case marker mismatch'})
        elif marker.startswith('END__'):
            if marker[len('END__'):] != current_case:
                parse_issues.append({'line': event_line, 'problem': 'end/case marker mismatch'})
            current_case = None
            current_phase = 'between_cases'
        continue
    rel = relative(target)
    if rel is None:
        continue
    all_repo_paths.add(rel)
    if re.search(r'O_WRONLY|O_RDWR|O_CREAT|O_TRUNC|O_APPEND', call):
        write_attempts.append({'path': rel, 'case_id': case_id, 'trace_line': event_line,
                               'success': bool(success), 'call': call})
    if not rel.startswith('assets/'):
        continue
    event = {'path': rel, 'case_id': case_id, 'phase': phase, 'pid': int(pid),
             'trace_line': event_line, 'success': bool(success)}
    if success:
        asset_events.append(event)
    else:
        event['error'] = failure.group(1)
        event['requested_open'] = call
        failed_asset_opens.append(event)
if pending:
    parse_issues.append({'problem': 'unfinished syscalls at end', 'pids': list(pending)})

by_path = defaultdict(list)
by_case = defaultdict(list)
for event in asset_events:
    by_path[event['path']].append(event)
    by_case[event['case_id']].append(event)
observed = []
for path, events in sorted(by_path.items()):
    observed.append({'path': path, 'open_count': len(events),
                     'case_ids': sorted({e['case_id'] for e in events if e['case_id']}),
                     'phases': dict(Counter(e['phase'] for e in events)),
                     'example_trace_lines': [e['trace_line'] for e in events[:3]],
                     'candidate': path in candidates})

outcomes = json.loads((WORK / 'worker_outcomes.json').read_text())
cases = []
reference_hits = defaultdict(list)
for outcome in outcomes:
    case_id = outcome['case_id']
    directory = WORK / 'cases' / case_id
    status_path = directory / 'status.json'
    if status_path.exists():
        case = json.loads(status_path.read_text())
    else:
        case = {'case_id': case_id, 'status': 'failure', 'failed_phase': 'worker_startup',
                'error': 'worker produced no status.json', 'phases_completed': []}
    case['worker'] = outcome
    if outcome.get('status') == 'timeout':
        case['status'] = 'timeout'
        case['error'] = 'worker exceeded 240-second timeout; partial opens retained'
    elif outcome.get('returncode') not in (0, 1) or case['status'] == 'running':
        case['status'] = 'failure'
        case.setdefault('error', f'worker exited unexpectedly: {outcome}')
    case['log_path'] = str(WORK / 'cases' / f'{case_id}.log')
    xml_path = directory / 'scene.xml'
    refs = []
    if xml_path.exists():
        root = ET.parse(xml_path).getroot()
        compiler = root.find('compiler')
        attributes = compiler.attrib if compiler is not None else {}
        for element in root.iter():
            filename = element.get('file')
            if not filename:
                continue
            directory_name = ''
            if element.tag == 'mesh':
                directory_name = attributes.get('meshdir', attributes.get('assetdir', ''))
            elif element.tag == 'texture':
                directory_name = attributes.get('texturedir', attributes.get('assetdir', ''))
            elif element.tag == 'hfield':
                directory_name = attributes.get('assetdir', '')
            resolved = os.path.normpath(os.path.join(str(xml_path.parent), directory_name, filename))
            rel = relative(resolved)
            refs.append({'element': element.tag, 'name': element.get('name'),
                         'declared_file': filename, 'resolved_path': rel or resolved,
                         'candidate': rel in candidates})
            if rel in candidates:
                reference_hits[rel].append(case_id)
        case['model_xml_path'] = str(xml_path)
        case['model_xml_sha256'] = sha(xml_path)
        refs_path = xml_path.parent / 'declared_resources.json'
        write(refs_path, refs)
        case['declared_resources_path'] = str(refs_path)
        case['declared_resource_count'] = len(refs)
        case['declared_reference_candidate_hits'] = sorted({r['resolved_path'] for r in refs if r['candidate']})
    events = by_case[case_id]
    calibration = [e for e in events if e['path'].startswith('assets/objects/calibrated_collision/') and e['path'].lower().endswith('.obj')]
    case['actual_calibration_obj_paths'] = sorted({e['path'] for e in calibration})
    case['actual_calibration_obj_open_count'] = len(calibration)
    case['actual_candidate_hits'] = sorted({e['path'] for e in events if e['path'] in candidates})
    case['failed_candidate_opens'] = [e for e in failed_asset_opens if e['case_id'] == case_id and e['path'] in candidates]
    cases.append(case)

# Hash observed source/config/manifest/XML inputs after tracing; never OBJ inventory.
input_hashes = {}
for path in sorted(all_repo_paths):
    p = ROOT / path
    if p.is_file() and p.suffix.lower() in ('.py', '.pyc', '.json', '.yaml', '.yml', '.xml'):
        input_hashes[path] = sha(p)
write(WORK / 'observed_source_config_sha256.json', input_hashes)
write(WORK / 'asset_open_events.json', asset_events)
write(WORK / 'markers.json', markers)

native_controls = [e for e in asset_events if e['phase'] == 'native_final_model_compile'
                   and e['path'] in production and e['path'].endswith('.obj')]
controls = []
seen = set()
for event in native_controls:
    if event['path'] not in seen:
        controls.append(event)
        seen.add(event['path'])
    if len(controls) >= 12:
        break
candidate_hits = [entry for entry in observed if entry['candidate']]
summary = {'task_count': len(json.loads((WORK / 'task_inventory.json').read_text())),
           'seeds': [2, 7, 19], 'attempted_cases': len(cases),
           'build_calls_recorded': sum(c.get('build_calls', 0) for c in cases),
           'status_counts': dict(Counter(c['status'] for c in cases)),
           'completed_build_cases': sum('build' in c['phases_completed'] for c in cases),
           'completed_final_compile_cases': sum('native_final_model_compile' in c['phases_completed'] for c in cases),
           'completed_forward_cases': sum('forward' in c['phases_completed'] for c in cases),
           'completed_single_step_cases': sum('single_step' in c['phases_completed'] for c in cases),
           'runtime_hook_counts': {name: sum(c.get('runtime_hooks', {}).get(name, False) for c in cases)
                                   for name in ('bind', 'after_reset', 'before_step', 'after_step')},
           'candidate_count': len(candidates), 'actual_candidate_path_count': len(candidate_hits),
           'declared_reference_candidate_path_count': len(reference_hits),
           'failed_candidate_open_count': sum(e['path'] in candidates for e in failed_asset_opens),
           'unique_asset_open_paths': len(observed), 'asset_open_event_count': len(asset_events),
           'unique_calibration_obj_paths': sum(e['path'].startswith('assets/objects/calibrated_collision/') and e['path'].endswith('.obj') for e in observed),
           'native_production_obj_open_count': len(native_controls),
           'native_production_obj_unique_paths': len({e['path'] for e in native_controls}),
           'markers_begin': sum(m['marker'].startswith('BEGIN__') for m in markers),
           'markers_end': sum(m['marker'].startswith('END__') for m in markers),
           'trace_lines': line_count, 'parser_issue_count': len(parse_issues),
           'repository_write_open_attempts': len(write_attempts),
           'repository_successful_write_opens': sum(e['success'] for e in write_attempts)}
result = {
    'suite': 'all_current_TASKS_real_build_native_load_forward_single_step',
    'method': {
        'enumeration': 'dex_scenes.registry.TASKS (51); task outer loop, seeds 2,7,19 inner loop',
        'build_api': 'TaskSpec.build(seed) -> dex_scenes.builder.build_scene(scene,name,seed), once per case',
        'serialization_api': 'ImportedSceneResult.composed_xml retained verbatim; procedural SceneBuildResult through dex_scenes.model_scene.write_scene_model(base,result,output,robot_manifest=manifest)',
        'load_api': 'mujoco.MjModel.from_xml_path(final_scene_xml); new mujoco.MjData(model)',
        'initialization': 'Imported saved model/data arrays restored with shape/finite checks; procedural XML carries object poses, robot joints initialized using resolve_model_addresses/resolve_home_positions',
        'forward_and_step': 'mujoco.mj_forward then one mujoco.mj_step on independent model/data; actual task runtime bind/after_reset/before_step/after_step only where runtime_key non-null',
        'trace': 'strace -f -yy -s 4096 -e trace=open,openat,openat2,chdir; BEGIN/PHASE/END marker opens; successful returned FD canonical paths; resumed syscalls joined per PID',
        'native_positive_control': 'Production OBJ opens strictly within native_final_model_compile phase: direct MjModel.from_xml_path call, no Python resource hashing in that phase',
        'candidate_matching': 'Exact normalized repo-relative paths against classification files primary_category=unknown and suffix .obj; no candidate OBJ directly opened by audit code',
        'hashing': 'Source/config and manifest/XML hashes computed outside traced processes; runtime model_cache fingerprint_asset is unchanged and may itself hash declared resources',
        'timeout_seconds_per_worker': 240,
    },
    'environment': {
        'repo': str(ROOT), 'cwd': str(WORK),
        'python': str(ROOT / '.pixi/envs/default/bin/python'), 'python_flags': ['-B'],
        'versions': {'python': '3.12.14', 'mujoco': '3.12.0', 'numpy': '2.5.3', 'PyYAML': '6.0.3'},
        'overrides': {'PYTHONPATH': str(ROOT/'src') + ':' + str(ROOT/'.ros/install/lib/python3.12/site-packages'), 'PYTHONDONTWRITEBYTECODE': '1',
                      'TMPDIR': str(WORK/'tmp'), 'SPD_ASSETS_ROOT': str(ROOT/'assets'),
                      'SPD_TASK_MATERIAL_FRICTION_DIR': str(WORK/'config/task_material_friction'),
                      'SPD_MATERIAL_FRICTION_CONFIG': str(WORK/'config/material_friction.yaml')},
        'sandbox': json.loads((WORK/'sandbox.json').read_text()),
        'configuration': 'No SceneRequest config_path supplied; live built-in defaults and unmodified copied per-task/global friction values; no geometry/physics overrides',
        'source_config_snapshot_path': str(WORK/'pre_run_source_config_sha256.json'),
        'source_config_snapshot_timing': 'Captured outside trace during initial import-only launch, before corrected actual build sweep',
        'observed_input_sha256_path': str(WORK/'observed_source_config_sha256.json'),
        'classification_sha256': sha(classification_path),
        'global_material_config_sha256': sha(ROOT/'config/material_friction.yaml'),
        'native_extension_path': str(ROOT/'.ros/install/lib/python3.12/site-packages/_spd_native.cpython-312-x86_64-linux-gnu.so'),
        'native_extension_sha256': sha(ROOT/'.ros/install/lib/python3.12/site-packages/_spd_native.cpython-312-x86_64-linux-gnu.so'),
    },
    'cases': cases,
    'observed_asset_opens': observed,
    'candidate_hits': candidate_hits,
    'declared_reference_candidate_hits': [{'path': p, 'case_ids': sorted(set(ids))} for p,ids in sorted(reference_hits.items())],
    'failed_asset_opens': failed_asset_opens,
    'failed_candidate_opens': [e for e in failed_asset_opens if e['path'] in candidates],
    'non_candidate_native_production_control_opens': controls,
    'trace_path': str(TRACE), 'trace_sha256': sha(TRACE),
    'probe_source_path': str(WORK/'probe.py'), 'probe_source_sha256': sha(WORK/'probe.py'),
    'summarizer_source_path': str(WORK/'summarize.py'), 'summarizer_source_sha256': sha(WORK/'summarize.py'),
    'asset_open_events_path': str(WORK/'asset_open_events.json'),
    'markers_path': str(WORK/'markers.json'), 'parse_issues': parse_issues,
    'retained_evidence': {
        'probe_and_runner_source': str(WORK/'probe.py'),
        'analyzer_source': str(WORK/'summarize.py'),
        'raw_traces': [str(TRACE), str(WORK/'startup_failure/trace.log')],
        'worker_stdout_stderr_logs': [str(WORK/'cases'/f"{c['case_id']}.log") for c in cases],
        'startup_stdout_stderr_logs': [str(p) for p in sorted((WORK/'startup_failure/cases').glob('*.log'))],
        'startup_diagnostic': str(WORK/'startup_failure/explanation.json'),
        'worker_outcomes': str(WORK/'worker_outcomes.json'),
        'task_inventory': str(WORK/'task_inventory.json'),
        'declaration_supplements': [c['declared_resources_path'] for c in cases if 'declared_resources_path' in c],
    },
    'pre_build_startup_failure': {
        'description': 'First launch omitted installed native extension directory from PYTHONPATH; 153 workers failed importing runtime before any TaskSpec.build call. Corrected environment then called build once per case. Startup failures are not counted as completed build cases.',
        'evidence_directory': str(WORK/'startup_failure'),
        'trace_path': str(WORK/'startup_failure/trace.log'),
        'trace_sha256': sha(WORK/'startup_failure/trace.log'),
        'worker_outcomes_path': str(WORK/'startup_failure/worker_outcomes.json'),
    },
    'repository_write_open_attempts': write_attempts,
    'failures': [{'case_id': c['case_id'], 'status': c['status'], 'phase': c.get('failed_phase', c.get('current_phase')), 'error': c.get('error')} for c in cases if c['status'] != 'success'],
    'limitations': [
        'Finite current task/seed coverage does not establish universal nonuse or authorize deletion.',
        'One independent native MuJoCo step is not a simulation rollout, production PlantController/native servo session, interactive collection, rendering, replay, or reset loop.',
        'Failed build cases retain partial resource opens but do not cover post-build model serialization, final compile, forward, or step.',
        'Production runtime model_cache may hash declared mesh inputs; observed opens include these genuine loader reads. Native final compile phase isolates MuJoCo OBJ opens as a positive control.',
        'Runtime hooks exercised only for registered non-null task runtime keys and only at reset plus a single step; conditional later branches are not exhausted.',
        'Landlock disallows filesystem mutation outside this audit child. No repository fixes, generated assets, or active-session connections were made.',
    ],
    'summary': summary,
}
write(WORK/'result.json', result)
print(json.dumps({'summary': summary, 'failures': result['failures'], 'result': str(WORK/'result.json')}, indent=2))
