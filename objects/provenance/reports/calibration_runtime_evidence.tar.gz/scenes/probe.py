"""Disposable audit: actual TaskSpec.build and independent MuJoCo load/step."""
import ctypes
import errno
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/summer/spd-zsm')
WORK = Path('/tmp/spd-calibration-runtime-audit-rx1s3u1r/scenes')


def restrict_writes():
    # Landlock handles only mutation rights: reads remain unrestricted, writes
    # are permitted only in this audit child. Inherited log FDs remain usable.
    libc = ctypes.CDLL(None, use_errno=True)
    version = libc.syscall(444, 0, 0, 1)
    if version < 3:
        raise RuntimeError(f'Landlock ABI >=3 required, got {version}, errno={ctypes.get_errno()}')
    class Ruleset(ctypes.Structure):
        _fields_ = [('handled_access_fs', ctypes.c_uint64)]
    class Beneath(ctypes.Structure):
        _pack_ = 1
        _fields_ = [('allowed_access', ctypes.c_uint64), ('parent_fd', ctypes.c_int)]
    rights = (1 << 1) | sum(1 << bit for bit in range(4, 15))
    ruleset = Ruleset(rights)
    fd = libc.syscall(444, ctypes.byref(ruleset), ctypes.sizeof(ruleset), 0)
    if fd < 0:
        raise OSError(ctypes.get_errno(), 'landlock_create_ruleset')
    path_fd = os.open(WORK, os.O_PATH | os.O_CLOEXEC)
    rule = Beneath(rights, path_fd)
    if libc.syscall(445, fd, 1, ctypes.byref(rule), 0) < 0:
        raise OSError(ctypes.get_errno(), 'landlock_add_rule')
    if libc.prctl(38, 1, 0, 0, 0) != 0 or libc.syscall(446, fd, 0) != 0:
        raise OSError(ctypes.get_errno(), 'landlock_restrict_self')
    os.close(path_fd)
    os.close(fd)
    return int(version)


def marker(name):
    with (WORK / 'markers' / name).open('wb'):
        pass


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def worker(index, seed):
    import mujoco
    import numpy as np
    from dex_scenes.registry import TASKS
    from dex_scenes.model_scene import write_scene_model
    from simulation.models.model_builder import description_root
    from simulation.models.manifest import load_manifest, resolve_model_addresses, resolve_home_positions
    from dex_scenes.runtime import make_task_runtime
    spec = TASKS[index]
    case_id = f'{index:02d}_{spec.scene}_{spec.name}_seed{seed}'
    directory = WORK / 'cases' / case_id
    directory.mkdir()
    phases = []
    record = {'case_id': case_id, 'task': spec.qualified_name, 'scene_key': spec.scene_key,
              'seed': seed, 'phases_completed': phases, 'build_calls': 0,
              'runtime_hooks': {key: False for key in ('bind', 'after_reset', 'before_step', 'after_step')},
              'status': 'running', 'started_monotonic': time.monotonic()}
    phase = 'build'
    def enter(name):
        marker(f'PHASE__{case_id}__{name}')
        record['current_phase'] = name
        save(directory / 'status.json', record)
    try:
        enter(phase)
        record['build_calls'] = 1
        save(directory / 'status.json', record)
        result = spec.build(seed)
        phases.append('build')
        record['result_type'] = type(result).__name__
        record['runtime_key'] = getattr(result, 'runtime_key', None)
        generated = description_root() / 'generated'
        manifest = load_manifest(generated / 'model_manifest.yaml')
        xml_path = directory / 'scene.xml'
        phase = 'serialize_final_model'
        enter(phase)
        if getattr(result, 'composed_xml', None) is not None:
            xml_path.write_text(result.composed_xml)
        else:
            write_scene_model(generated / 'unified_plant.xml', result, xml_path, robot_manifest=manifest)
        phases.append(phase)
        record['model_xml_path'] = str(xml_path)
        phase = 'native_final_model_compile'
        enter(phase)
        model = mujoco.MjModel.from_xml_path(str(xml_path))
        data = mujoco.MjData(model)
        phases.append(phase)
        phase = 'initialize_result_state'
        enter(phase)
        state = getattr(result, 'initial_state', None)
        if state is not None:
            # Same arrays preserved by builder._initial_state and restored by
            # viewer._apply_model_state/_apply_data_state; no resampling.
            for name, value in state.get('model', {}).items():
                target = getattr(model, name)
                values = np.asarray(value, dtype=target.dtype)
                if target.shape != values.shape or not np.all(np.isfinite(values)):
                    raise ValueError(f'invalid saved model array {name}')
                target[:] = values
            for name in ('qpos', 'qvel', 'ctrl', 'act'):
                target = getattr(data, name)
                values = np.asarray(state[name], dtype=target.dtype)
                if target.shape != values.shape or not np.all(np.isfinite(values)):
                    raise ValueError(f'invalid saved data array {name}')
                target[:] = values
            data.time = float(state.get('time', 0))
        else:
            joints = resolve_model_addresses(model, manifest, allow_scene_dofs=True)
            home = resolve_home_positions(joints, manifest)
            for joint in joints:
                data.qpos[joint.qpos_address] = home[joint.index]
        phases.append(phase)
        phase = 'forward'
        enter(phase)
        mujoco.mj_forward(model, data)
        phases.append(phase)
        runtime = None
        if record['runtime_key'] is not None:
            phase = 'runtime_bind_after_reset'
            enter(phase)
            runtime = make_task_runtime(record['runtime_key'], model, data)
            record['runtime_hooks']['bind'] = True
            runtime.after_reset(model, data, randomization=result.randomization)
            record['runtime_hooks']['after_reset'] = True
            phases.append(phase)
        phase = 'single_step'
        enter(phase)
        if runtime is not None:
            runtime.before_step(model, data)
            record['runtime_hooks']['before_step'] = True
        initial_time = float(data.time)
        mujoco.mj_step(model, data)
        if runtime is not None:
            runtime.after_step(model, data)
            record['runtime_hooks']['after_step'] = True
        record['step'] = {'count': 1, 'start_time': initial_time, 'end_time': float(data.time),
                          'dt': float(model.opt.timestep),
                          'finite_qpos_qvel': bool(np.all(np.isfinite(data.qpos)) and np.all(np.isfinite(data.qvel))),
                          'warning_counts': [int(w.number) for w in data.warning]}
        phases.append(phase)
        record['model_sizes'] = {'nq': model.nq, 'nv': model.nv, 'nmesh': model.nmesh, 'ngeom': model.ngeom}
        record['status'] = 'success'
    except BaseException as exc:
        record.update(status='failure', failed_phase=phase, exception_type=type(exc).__name__,
                      error=str(exc), traceback=traceback.format_exc())
    finally:
        record['elapsed_seconds'] = time.monotonic() - record['started_monotonic']
        save(directory / 'status.json', record)
    return 0 if record['status'] == 'success' else 1


def orchestrate():
    from dex_scenes.registry import TASKS
    if len(TASKS) != 51:
        raise RuntimeError(f'expected current 51 tasks, got {len(TASKS)}')
    save(WORK / 'task_inventory.json', [{'index': i, 'task': spec.qualified_name,
          'scene_key': spec.scene_key, 'runtime_key': spec.runtime_key} for i, spec in enumerate(TASKS)])
    outcomes = []
    for index, spec in enumerate(TASKS):
        for seed in (2, 7, 19):
            case_id = f'{index:02d}_{spec.scene}_{spec.name}_seed{seed}'
            marker(f'BEGIN__{case_id}')
            started = time.monotonic()
            with (WORK / 'cases' / f'{case_id}.log').open('wb') as log:
                try:
                    completed = subprocess.run([sys.executable, '-B', __file__, '--worker', str(index), str(seed)],
                                               stdout=log, stderr=subprocess.STDOUT, timeout=240, check=False)
                    outcome = {'case_id': case_id, 'returncode': completed.returncode}
                except subprocess.TimeoutExpired:
                    outcome = {'case_id': case_id, 'status': 'timeout', 'timeout_seconds': 240}
            marker(f'END__{case_id}')
            outcome['elapsed_seconds'] = time.monotonic() - started
            outcomes.append(outcome)
            save(WORK / 'worker_outcomes.json', outcomes)
            print(json.dumps(outcome), flush=True)
    return 0


if __name__ == '__main__':
    abi = restrict_writes()
    if '--worker' in sys.argv:
        sys.exit(worker(int(sys.argv[2]), int(sys.argv[3])))
    save(WORK / 'sandbox.json', {'mechanism': 'Landlock', 'abi': abi,
         'write_allowlist': [str(WORK)], 'repository_mutation_access': 'denied',
         'bwrap_unavailable': 'setting up uid map: Permission denied'})
    sys.exit(orchestrate())
